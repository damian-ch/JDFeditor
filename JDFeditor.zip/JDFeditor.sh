#!/bin/bash

python jdf_editor.py
